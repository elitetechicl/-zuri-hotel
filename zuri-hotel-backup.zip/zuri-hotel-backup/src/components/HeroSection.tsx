import { useState } from "react";
import { useNavigate } from "react-router-dom";
import heroImg from "@/assets/hero-hotel.jpg";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const HeroSection = () => {
  const [form, setForm] = useState({ name: "", email: "", date: "", guests: "2" });
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { data, error } = await supabase.from("bookings").insert({
        name: form.name,
        email: form.email,
        phone: "N/A",
        room_type: "deluxe",
        check_in: form.date,
        check_out: form.date,
        guests: parseInt(form.guests),
      }).select("id").single();
      if (error) throw error;
      toast.success("Thank you! Redirecting to your confirmation page...");
      setForm({ name: "", email: "", date: "", guests: "2" });
      navigate(`/booking/${data.id}`);
    } catch (err: any) {
      toast.error(err.message || "Failed to submit reservation");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="relative min-h-screen flex items-center pt-20">
      <div className="absolute inset-0">
        <img src={heroImg} alt="Zuri Hotel luxury exterior at golden hour" width={1920} height={1080} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-primary/60" />
      </div>

      <div className="relative z-10 container mx-auto section-padding grid lg:grid-cols-2 gap-12 items-center">
        <div className="animate-fade-up">
          <p className="text-gold font-sans text-sm tracking-[0.3em] uppercase mb-4">Welcome to Zuri Hotel</p>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-primary-foreground leading-tight mb-6">
            Where Luxury Meets <span className="text-gold-gradient italic">Timeless Elegance</span>
          </h1>
          <p className="text-primary-foreground/80 font-sans text-lg max-w-lg mb-8 leading-relaxed">
            Experience world-class hospitality, exquisite dining, and serene relaxation at Zuri Hotel — your sanctuary of sophistication.
          </p>
          <div className="flex items-center gap-6">
            <a href="#services" className="gold-gradient text-primary font-semibold text-sm px-8 py-3 rounded-sm tracking-wide uppercase hover:opacity-90 transition-opacity">
              Explore
            </a>
            <a href="#gallery" className="border border-gold/50 text-gold font-semibold text-sm px-8 py-3 rounded-sm tracking-wide uppercase hover:bg-gold/10 transition-colors">
              View Gallery
            </a>
          </div>
        </div>

        <div className="animate-fade-up" style={{ animationDelay: "0.2s" }}>
          <form onSubmit={handleSubmit} className="bg-background/95 backdrop-blur-sm p-8 rounded-sm shadow-2xl">
            <h3 className="font-serif text-2xl text-foreground mb-1">Reserve Your Stay</h3>
            <p className="text-muted-foreground text-sm mb-6">Fill in your details and we'll get back to you.</p>
            <div className="space-y-4">
              <input type="text" placeholder="Full Name" required maxLength={100} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50" />
              <input type="email" placeholder="Email Address" required maxLength={255} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50" />
              <div className="grid grid-cols-2 gap-4">
                <input type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50" />
                <select value={form.guests} onChange={(e) => setForm({ ...form, guests: e.target.value })} className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50">
                  {[1, 2, 3, 4, 5, 6].map((n) => (
                    <option key={n} value={n}>{n} Guest{n > 1 ? "s" : ""}</option>
                  ))}
                </select>
              </div>
              <button type="submit" disabled={submitting} className="w-full gold-gradient text-primary font-semibold py-3 rounded-sm tracking-wide uppercase text-sm hover:opacity-90 transition-opacity disabled:opacity-50">
                {submitting ? "Submitting..." : "Request Reservation"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
