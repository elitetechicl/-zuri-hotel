const CTASection = () => (
  <section className="relative section-padding bg-primary overflow-hidden">
    <div className="absolute top-0 left-0 w-64 h-64 rounded-full bg-gold/5 -translate-x-1/2 -translate-y-1/2" />
    <div className="absolute bottom-0 right-0 w-96 h-96 rounded-full bg-gold/5 translate-x-1/3 translate-y-1/3" />
    <div className="relative container mx-auto text-center max-w-2xl">
      <p className="text-gold font-sans text-sm tracking-[0.3em] uppercase mb-3">Start Your Journey</p>
      <h2 className="font-serif text-3xl md:text-5xl text-primary-foreground mb-6 leading-tight">
        Your Extraordinary Stay <span className="italic text-gold">Awaits</span>
      </h2>
      <p className="text-primary-foreground/70 text-lg mb-10 leading-relaxed">
        Book your stay at Zuri Hotel today and experience the pinnacle of luxury, comfort, and unforgettable moments.
      </p>
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
        <a href="#contact" className="gold-gradient text-primary font-semibold text-sm px-10 py-3.5 rounded-sm tracking-wide uppercase hover:opacity-90 transition-opacity">
          Reserve Now
        </a>
        <a href="tel:+1234567890" className="border border-gold/50 text-gold font-semibold text-sm px-10 py-3.5 rounded-sm tracking-wide uppercase hover:bg-gold/10 transition-colors">
          Call Us
        </a>
      </div>
    </div>
  </section>
);

export default CTASection;
