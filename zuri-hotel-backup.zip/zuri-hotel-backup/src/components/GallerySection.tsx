import galleryRestaurant from "@/assets/gallery-restaurant.jpg";
import gallerySuite from "@/assets/gallery-suite.jpg";
import galleryPool from "@/assets/gallery-pool.jpg";
import gallerySpa from "@/assets/gallery-spa.jpg";
import galleryBar from "@/assets/gallery-bar.jpg";
import heroHotel from "@/assets/hero-hotel.jpg";

const images = [
  { src: gallerySuite, alt: "Luxury suite at Zuri Hotel", label: "The Suite" },
  { src: galleryRestaurant, alt: "Fine dining restaurant", label: "Fine Dining" },
  { src: galleryPool, alt: "Infinity pool at sunset", label: "Infinity Pool" },
  { src: gallerySpa, alt: "Spa treatment room", label: "The Spa" },
  { src: galleryBar, alt: "Cocktail lounge", label: "Cocktail Bar" },
  { src: heroHotel, alt: "Zuri Hotel exterior", label: "The Hotel" },
];

const GallerySection = () => (
  <section id="gallery" className="section-padding bg-background">
    <div className="container mx-auto">
      <div className="text-center mb-16">
        <p className="text-gold font-sans text-sm tracking-[0.3em] uppercase mb-3">Gallery</p>
        <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">A Glimpse of <span className="italic text-gold">Zuri</span></h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">Step inside and explore the beauty of our hotel through these curated moments.</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {images.map((img) => (
          <div key={img.label} className="group relative overflow-hidden rounded-sm aspect-square">
            <img src={img.src} alt={img.alt} loading="lazy" width={800} height={800} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
            <div className="absolute inset-0 bg-primary/0 group-hover:bg-primary/50 transition-colors duration-500 flex items-end">
              <span className="text-primary-foreground font-serif text-lg p-4 opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-500">{img.label}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default GallerySection;
