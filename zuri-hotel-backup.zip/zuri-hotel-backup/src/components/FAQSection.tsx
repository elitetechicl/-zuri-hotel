import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqs = [
  { q: "What are the check-in and check-out times?", a: "Check-in begins at 3:00 PM and check-out is at 11:00 AM. Early check-in and late check-out can be arranged upon request, subject to availability." },
  { q: "Does the hotel have a restaurant?", a: "Yes! Zuri Hotel features an award-winning fine dining restaurant, a casual poolside café, and a cocktail lounge — all serving exquisite cuisine prepared by our world-class chefs." },
  { q: "Is airport transfer available?", a: "Absolutely. We offer complimentary luxury airport transfers for suite guests. Standard transfer services are available for all guests at a nominal fee." },
  { q: "What amenities are included in the room?", a: "Every room includes high-speed Wi-Fi, a minibar, premium toiletries, plush robes, a flat-screen TV, and 24-hour room service. Suites also include a private balcony and lounge area." },
  { q: "Can I host events or weddings at Zuri Hotel?", a: "Yes, we have elegant event spaces and a dedicated events team to help you plan unforgettable weddings, corporate events, and private celebrations." },
  { q: "Is there a spa on-site?", a: "Our full-service spa offers a menu of holistic treatments, massages, facials, and wellness rituals. Pre-booking is recommended to secure your preferred time." },
];

const FAQSection = () => (
  <section id="faq" className="section-padding bg-secondary">
    <div className="container mx-auto max-w-3xl">
      <div className="text-center mb-16">
        <p className="text-gold font-sans text-sm tracking-[0.3em] uppercase mb-3">FAQ</p>
        <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">Frequently Asked <span className="italic text-gold">Questions</span></h2>
        <p className="text-muted-foreground">Everything you need to know before your stay at Zuri Hotel.</p>
      </div>
      <Accordion type="single" collapsible className="space-y-3">
        {faqs.map((faq, i) => (
          <AccordionItem key={i} value={`item-${i}`} className="bg-background border border-border rounded-sm px-6">
            <AccordionTrigger className="font-serif text-foreground text-left hover:text-gold transition-colors py-5">
              {faq.q}
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-5">
              {faq.a}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  </section>
);

export default FAQSection;
