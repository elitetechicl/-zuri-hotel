import { useState } from "react";

const BookingForm = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    checkIn: "",
    checkOut: "",
    guests: "2",
    roomType: "deluxe",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Thank you! We'll confirm your booking shortly.");
    setForm({ name: "", email: "", phone: "", checkIn: "", checkOut: "", guests: "2", roomType: "deluxe", message: "" });
  };

  return (
    <section id="booking" className="section-padding bg-secondary">
      <div className="container mx-auto max-w-5xl">
        <div className="text-center mb-12">
          <p className="text-gold font-sans text-sm tracking-[0.3em] uppercase mb-3">Reservations</p>
          <h2 className="font-serif text-3xl md:text-5xl text-foreground mb-4">
            Book Your <span className="italic text-gold-gradient">Stay</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto leading-relaxed">
            Complete the form below and our concierge team will confirm your reservation within 24 hours.
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-background/95 backdrop-blur-sm p-8 md:p-12 rounded-sm shadow-2xl border border-border"
        >
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-foreground text-sm font-medium">Full Name</label>
              <input
                type="text"
                placeholder="John Doe"
                required
                maxLength={100}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              />
            </div>
            <div className="space-y-2">
              <label className="text-foreground text-sm font-medium">Email Address</label>
              <input
                type="email"
                placeholder="john@example.com"
                required
                maxLength={255}
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              />
            </div>
            <div className="space-y-2">
              <label className="text-foreground text-sm font-medium">Phone Number</label>
              <input
                type="tel"
                placeholder="+254 700 000 000"
                required
                maxLength={20}
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              />
            </div>
            <div className="space-y-2">
              <label className="text-foreground text-sm font-medium">Room Type</label>
              <select
                value={form.roomType}
                onChange={(e) => setForm({ ...form, roomType: e.target.value })}
                className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              >
                <option value="standard">Standard Room</option>
                <option value="deluxe">Deluxe Room</option>
                <option value="suite">Executive Suite</option>
                <option value="penthouse">Penthouse Suite</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-foreground text-sm font-medium">Check-In Date</label>
              <input
                type="date"
                required
                value={form.checkIn}
                onChange={(e) => setForm({ ...form, checkIn: e.target.value })}
                className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              />
            </div>
            <div className="space-y-2">
              <label className="text-foreground text-sm font-medium">Check-Out Date</label>
              <input
                type="date"
                required
                value={form.checkOut}
                onChange={(e) => setForm({ ...form, checkOut: e.target.value })}
                className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              />
            </div>
            <div className="space-y-2">
              <label className="text-foreground text-sm font-medium">Number of Guests</label>
              <select
                value={form.guests}
                onChange={(e) => setForm({ ...form, guests: e.target.value })}
                className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              >
                {[1, 2, 3, 4, 5, 6].map((n) => (
                  <option key={n} value={n}>{n} Guest{n > 1 ? "s" : ""}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-foreground text-sm font-medium">Special Requests</label>
              <textarea
                placeholder="Any special requests or notes..."
                maxLength={500}
                rows={1}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50 resize-none"
              />
            </div>
          </div>
          <button
            type="submit"
            className="mt-8 w-full md:w-auto gold-gradient text-primary font-semibold py-3 px-12 rounded-sm tracking-wide uppercase text-sm hover:opacity-90 transition-opacity"
          >
            Request Booking
          </button>
        </form>
      </div>
    </section>
  );
};

export default BookingForm;
