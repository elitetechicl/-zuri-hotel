import { Wifi, Users, Building2, Utensils } from "lucide-react";

const facilities = [
  { icon: Wifi, title: "Complimentary WiFi", desc: "Stay connected with high-speed, complimentary WiFi available throughout the hotel and in all guest rooms." },
  { icon: Users, title: "24/7 Concierge Staff", desc: "Our dedicated team is available around the clock to assist with any request, from travel arrangements to dining reservations." },
  { icon: Building2, title: "Conference Halls", desc: "Elegant meeting and event spaces equipped with modern AV technology for business conferences and celebrations." },
  { icon: Utensils, title: "Fine Dining Restaurant", desc: "An exquisite culinary experience featuring gourmet dishes prepared by our world-class chefs in an elegant setting." },
];

const FacilitiesSection = () => (
  <section id="facilities" className="section-padding bg-muted">
    <div className="container mx-auto">
      <div className="text-center mb-16">
        <p className="text-gold font-sans text-sm tracking-[0.3em] uppercase mb-3">Grand Hotel Amenities</p>
        <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">Facilities & <span className="italic text-gold">Services</span></h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          From modern amenities to round-the-clock support, our facilities are designed to ensure your stay is seamless and memorable.
        </p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {facilities.map((f) => (
          <div key={f.title} className="group bg-background border border-border p-8 rounded-sm hover:border-gold/40 hover:shadow-lg transition-all duration-300">
            <div className="w-12 h-12 rounded-sm gold-gradient flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <f.icon className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-serif text-xl text-foreground mb-2">{f.title}</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">{f.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default FacilitiesSection;
