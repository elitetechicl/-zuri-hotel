import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Menu, X, ChevronDown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const navLinks = [
  { label: "Services", href: "#services" },
  { label: "Why Us", href: "#why-us" },
  { label: "Gallery", href: "#gallery" },
  { label: "FAQ", href: "#faq" },
];

const BookingDropdownForm = ({ onClose }: { onClose: () => void }) => {
  const [form, setForm] = useState({
    name: "", email: "", phone: "", checkIn: "", checkOut: "", guests: "2", roomType: "deluxe", message: "",
  });
  const navigate = useNavigate();

  const [submitting, setSubmitting] = useState(false);

  const roomOptions = [
    { value: "standard", label: "Standard Room", price: 2000 },
    { value: "deluxe", label: "Deluxe Room", price: 4500 },
    { value: "suite", label: "Executive Suite", price: 7000 },
    { value: "penthouse", label: "Penthouse Suite", price: 10000 },
  ];

  const selectedRoom = roomOptions.find((r) => r.value === form.roomType)!;
  const nights = form.checkIn && form.checkOut
    ? Math.max(0, Math.ceil((new Date(form.checkOut).getTime() - new Date(form.checkIn).getTime()) / (1000 * 60 * 60 * 24)))
    : 0;
  const total = selectedRoom.price * nights;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { data, error } = await supabase.from("bookings").insert({
        name: form.name,
        email: form.email,
        phone: form.phone,
        room_type: form.roomType,
        check_in: form.checkIn,
        check_out: form.checkOut,
        guests: parseInt(form.guests),
        message: form.message || null,
      }).select("id").single();
      if (error) throw error;
      toast.success("Booking submitted! Redirecting to your confirmation page...");
      setForm({ name: "", email: "", phone: "", checkIn: "", checkOut: "", guests: "2", roomType: "deluxe", message: "" });
      onClose();
      navigate(`/booking/${data.id}`);
    } catch (err: any) {
      toast.error(err.message || "Failed to submit booking");
    } finally {
      setSubmitting(false);
    }
  };

  const inputClass = "w-full px-3 py-2.5 bg-secondary border border-border rounded-sm text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50";

  return (
    <form onSubmit={handleSubmit} className="grid sm:grid-cols-2 gap-4">
      <div className="space-y-1">
        <label className="text-foreground text-xs font-medium">Full Name</label>
        <input type="text" placeholder="John Doe" required maxLength={100} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputClass} />
      </div>
      <div className="space-y-1">
        <label className="text-foreground text-xs font-medium">Email</label>
        <input type="email" placeholder="john@example.com" required maxLength={255} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputClass} />
      </div>
      <div className="space-y-1">
        <label className="text-foreground text-xs font-medium">Phone</label>
        <input type="tel" placeholder="+254 700 000 000" required maxLength={20} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={inputClass} />
      </div>
      <div className="space-y-1">
        <label className="text-foreground text-xs font-medium">Room Type</label>
        <select value={form.roomType} onChange={(e) => setForm({ ...form, roomType: e.target.value })} className={inputClass}>
          {roomOptions.map((r) => (
            <option key={r.value} value={r.value}>
              {r.label} — KSh {r.price.toLocaleString()}/night
            </option>
          ))}
        </select>
      </div>
      <div className="space-y-1">
        <label className="text-foreground text-xs font-medium">Check-In</label>
        <input type="date" required value={form.checkIn} onChange={(e) => setForm({ ...form, checkIn: e.target.value })} className={inputClass} />
      </div>
      <div className="space-y-1">
        <label className="text-foreground text-xs font-medium">Check-Out</label>
        <input type="date" required value={form.checkOut} onChange={(e) => setForm({ ...form, checkOut: e.target.value })} className={inputClass} />
      </div>
      <div className="space-y-1">
        <label className="text-foreground text-xs font-medium">Guests</label>
        <select value={form.guests} onChange={(e) => setForm({ ...form, guests: e.target.value })} className={inputClass}>
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <option key={n} value={n}>{n} Guest{n > 1 ? "s" : ""}</option>
          ))}
        </select>
      </div>
      <div className="space-y-1">
        <label className="text-foreground text-xs font-medium">Special Requests</label>
        <input type="text" placeholder="Any notes..." maxLength={500} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className={inputClass} />
      </div>
      <div className="sm:col-span-2 flex items-center justify-between bg-secondary/60 border border-border rounded-sm px-4 py-3 mt-1">
        <div className="text-xs text-muted-foreground">
          {nights > 0 ? `${nights} night${nights > 1 ? "s" : ""} × KSh ${selectedRoom.price.toLocaleString()}` : "Select dates to see total"}
        </div>
        <div className="font-serif text-lg text-gold">
          {nights > 0 ? `KSh ${total.toLocaleString()}` : "—"}
        </div>
      </div>
      <div className="sm:col-span-2 pt-1">
        <button type="submit" disabled={submitting} className="w-full gold-gradient text-primary font-semibold py-2.5 rounded-sm tracking-wide uppercase text-sm hover:opacity-90 transition-opacity disabled:opacity-50">
          {submitting ? "Submitting..." : "Request Booking"}
        </button>
      </div>
    </form>
  );
};

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setBookingOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-primary/95 backdrop-blur-md border-b border-foreground/10">
      <div className="container mx-auto flex items-center justify-between py-4">
        <a href="#" className="font-serif text-2xl font-bold text-primary-foreground tracking-wide">
          ZURI <span className="text-gold">HOTEL</span>
        </a>
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((l) => (
            <a key={l.href} href={l.href} className="text-primary-foreground/80 hover:text-gold transition-colors text-sm font-medium tracking-wide uppercase">
              {l.label}
            </a>
          ))}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setBookingOpen(!bookingOpen)}
              className="gold-gradient text-primary font-semibold text-sm px-6 py-2.5 rounded-sm tracking-wide uppercase hover:opacity-90 transition-opacity flex items-center gap-1.5"
            >
              Book Now <ChevronDown size={14} className={`transition-transform ${bookingOpen ? "rotate-180" : ""}`} />
            </button>
            {bookingOpen && (
              <div className="absolute right-0 top-full mt-3 w-[480px] bg-background border border-border rounded-sm shadow-2xl p-6 animate-fade-up">
                <h3 className="font-serif text-xl text-foreground mb-1">Reserve Your Stay</h3>
                <p className="text-muted-foreground text-xs mb-4">Fill in details and we'll confirm within 24 hours.</p>
                <BookingDropdownForm onClose={() => setBookingOpen(false)} />
              </div>
            )}
          </div>
        </div>
        <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden text-primary-foreground">
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      {mobileOpen && (
        <div className="md:hidden bg-primary border-t border-foreground/10 pb-6">
          {navLinks.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setMobileOpen(false)} className="block px-6 py-3 text-primary-foreground/80 hover:text-gold transition-colors text-sm tracking-wide uppercase">
              {l.label}
            </a>
          ))}
          <div className="px-6 pt-2">
            <button
              onClick={() => setBookingOpen(!bookingOpen)}
              className="block w-full text-center gold-gradient text-primary font-semibold text-sm px-6 py-2.5 rounded-sm tracking-wide uppercase"
            >
              Book Now
            </button>
            {bookingOpen && (
              <div className="mt-3 bg-background border border-border rounded-sm p-5">
                <h3 className="font-serif text-lg text-foreground mb-1">Reserve Your Stay</h3>
                <p className="text-muted-foreground text-xs mb-4">Fill in details and we'll confirm within 24 hours.</p>
                <BookingDropdownForm onClose={() => { setBookingOpen(false); setMobileOpen(false); }} />
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
