const Footer = () => (
  <footer className="bg-foreground py-12 px-6">
    <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
      <div>
        <p className="font-serif text-xl text-background font-bold tracking-wide">ZURI <span className="text-gold">HOTEL</span></p>
        <p className="text-background/50 text-sm mt-1">Luxury Redefined</p>
      </div>
      <div className="flex items-center gap-8">
        {["Services", "Gallery", "FAQ"].map((l) => (
          <a key={l} href={`#${l.toLowerCase().replace(" ", "-")}`} className="text-background/60 hover:text-gold transition-colors text-sm tracking-wide uppercase">
            {l}
          </a>
        ))}
      </div>
      <p className="text-background/40 text-xs">&copy; {new Date().getFullYear()} Zuri Hotel. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;
