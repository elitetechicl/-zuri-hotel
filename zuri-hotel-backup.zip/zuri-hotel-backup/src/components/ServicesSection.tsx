import { Bed, UtensilsCrossed, Waves, Wine, Sparkles, Car } from "lucide-react";

const services = [
  { icon: Bed, title: "Luxury Suites", desc: "Elegantly appointed rooms with premium amenities, plush bedding, and breathtaking views." },
  { icon: UtensilsCrossed, title: "Fine Dining", desc: "Savor world-class cuisine crafted by award-winning chefs using the freshest local ingredients." },
  { icon: Waves, title: "Infinity Pool", desc: "Relax by our stunning infinity pool overlooking tropical gardens and the horizon." },
  { icon: Sparkles, title: "Spa & Wellness", desc: "Rejuvenate with holistic treatments, massages, and wellness rituals in our tranquil spa." },
  { icon: Wine, title: "Cocktail Lounge", desc: "Unwind with handcrafted cocktails and curated wines in our sophisticated lounge." },
  { icon: Car, title: "Concierge & Transfers", desc: "Seamless airport transfers and 24/7 concierge service for a stress-free experience." },
];

const ServicesSection = () => (
  <section id="services" className="section-padding bg-background">
    <div className="container mx-auto">
      <div className="text-center mb-16">
        <p className="text-gold font-sans text-sm tracking-[0.3em] uppercase mb-3">Our Services</p>
        <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">Everything You Need for a <span className="italic text-gold">Perfect Stay</span></h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">From luxurious accommodations to unforgettable dining, every detail at Zuri Hotel is designed to exceed your expectations.</p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((s) => (
          <div key={s.title} className="group bg-card border border-border p-8 rounded-sm hover:border-gold/40 hover:shadow-lg transition-all duration-300">
            <div className="w-12 h-12 rounded-sm gold-gradient flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <s.icon className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-serif text-xl text-foreground mb-2">{s.title}</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">{s.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default ServicesSection;
