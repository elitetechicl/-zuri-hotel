import { Award, Heart, MapPin, Clock } from "lucide-react";

const reasons = [
  { icon: Award, title: "Award-Winning Hospitality", desc: "Recognized for excellence in luxury hospitality and guest satisfaction year after year." },
  { icon: MapPin, title: "Prime Location", desc: "Situated in the heart of the city with easy access to attractions, culture, and nature." },
  { icon: Heart, title: "Personalized Experience", desc: "Every stay is tailored to your preferences — from room setup to dining and activities." },
  { icon: Clock, title: "24/7 Dedicated Service", desc: "Our team is available around the clock to ensure your comfort and address every need." },
];

const WhyUsSection = () => (
  <section id="why-us" className="section-padding bg-primary">
    <div className="container mx-auto">
      <div className="text-center mb-16">
        <p className="text-gold font-sans text-sm tracking-[0.3em] uppercase mb-3">Why Choose Zuri</p>
        <h2 className="font-serif text-3xl md:text-4xl text-primary-foreground mb-4">A Stay You'll <span className="italic text-gold">Never Forget</span></h2>
        <p className="text-primary-foreground/70 max-w-2xl mx-auto">We don't just offer rooms — we create memories. Here's what sets Zuri Hotel apart.</p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {reasons.map((r) => (
          <div key={r.title} className="text-center group">
            <div className="w-16 h-16 mx-auto rounded-full border-2 border-gold/40 flex items-center justify-center mb-5 group-hover:border-gold group-hover:bg-gold/10 transition-all duration-300">
              <r.icon className="w-7 h-7 text-gold" />
            </div>
            <h3 className="font-serif text-lg text-primary-foreground mb-2">{r.title}</h3>
            <p className="text-primary-foreground/60 text-sm leading-relaxed">{r.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default WhyUsSection;
