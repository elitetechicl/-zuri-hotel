import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const AdminLogin = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;

      // Check if user has admin role
      const { data: roles, error: roleError } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", data.user.id)
        .eq("role", "admin");

      if (roleError || !roles || roles.length === 0) {
        await supabase.auth.signOut();
        toast.error("Access denied. You are not an admin.");
        return;
      }

      toast.success("Welcome back, Admin!");
      navigate("/admin");
    } catch (err: any) {
      toast.error(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-primary flex items-center justify-center px-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <a href="/" className="font-serif text-2xl font-bold text-primary-foreground tracking-wide">
            ZURI <span className="text-gold">HOTEL</span>
          </a>
          <p className="text-primary-foreground/60 text-sm mt-2">Admin Portal</p>
        </div>
        <form onSubmit={handleLogin} className="bg-background p-8 rounded-sm shadow-2xl space-y-5">
          <h2 className="font-serif text-2xl text-foreground mb-2">Sign In</h2>
          <div className="space-y-1">
            <label className="text-foreground text-sm font-medium">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              placeholder="admin@zurihotel.com"
            />
          </div>
          <div className="space-y-1">
            <label className="text-foreground text-sm font-medium">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full gold-gradient text-primary font-semibold py-3 rounded-sm tracking-wide uppercase text-sm hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
