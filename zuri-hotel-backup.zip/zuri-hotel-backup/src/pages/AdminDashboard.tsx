import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { LogOut, CheckCircle, XCircle, Clock, Mail, Phone, Calendar, Users, MessageSquare } from "lucide-react";

type Booking = {
  id: string;
  name: string;
  email: string;
  phone: string;
  room_type: string;
  check_in: string;
  check_out: string;
  guests: number;
  message: string | null;
  status: "pending" | "accepted" | "denied";
  admin_notes: string | null;
  created_at: string;
};

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-300",
  accepted: "bg-green-100 text-green-800 border-green-300",
  denied: "bg-red-100 text-red-800 border-red-300",
};

const statusIcons = {
  pending: Clock,
  accepted: CheckCircle,
  denied: XCircle,
};

const AdminDashboard = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "pending" | "accepted" | "denied">("all");
  const [adminNotes, setAdminNotes] = useState<Record<string, string>>({});
  const navigate = useNavigate();

  useEffect(() => {
    checkAuth();
    fetchBookings();

    const channel = supabase
      .channel("bookings-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "bookings" }, () => {
        fetchBookings();
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  const checkAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate("/admin/login");
      return;
    }
    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", session.user.id)
      .eq("role", "admin");

    if (!roles || roles.length === 0) {
      await supabase.auth.signOut();
      navigate("/admin/login");
    }
  };

  const fetchBookings = async () => {
    const { data, error } = await supabase
      .from("bookings")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Failed to load bookings");
    } else {
      setBookings((data as Booking[]) || []);
    }
    setLoading(false);
  };

  const updateStatus = async (id: string, status: "accepted" | "denied") => {
    const notes = adminNotes[id] || null;
    const { error } = await supabase
      .from("bookings")
      .update({ status, admin_notes: notes })
      .eq("id", id);

    if (error) {
      toast.error("Failed to update booking");
    } else {
      toast.success(`Booking ${status}!`);
      fetchBookings();
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/admin/login");
  };

  const filtered = filter === "all" ? bookings : bookings.filter((b) => b.status === filter);
  const counts = {
    all: bookings.length,
    pending: bookings.filter((b) => b.status === "pending").length,
    accepted: bookings.filter((b) => b.status === "accepted").length,
    denied: bookings.filter((b) => b.status === "denied").length,
  };

  return (
    <div className="min-h-screen bg-secondary">
      {/* Header */}
      <header className="bg-primary text-primary-foreground py-4 px-6 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-4">
          <a href="/" className="font-serif text-xl font-bold tracking-wide">
            ZURI <span className="text-gold">HOTEL</span>
          </a>
          <span className="text-primary-foreground/50 text-sm hidden sm:inline">| Admin Dashboard</span>
        </div>
        <button onClick={handleLogout} className="flex items-center gap-2 text-primary-foreground/70 hover:text-gold transition-colors text-sm">
          <LogOut size={16} /> Sign Out
        </button>
      </header>

      <div className="container mx-auto px-6 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {(["all", "pending", "accepted", "denied"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`p-4 rounded-sm border transition-all text-left ${
                filter === s ? "border-gold bg-background shadow-md" : "border-border bg-background/50 hover:bg-background"
              }`}
            >
              <p className="text-muted-foreground text-xs uppercase tracking-wide capitalize">{s}</p>
              <p className="font-serif text-2xl text-foreground mt-1">{counts[s]}</p>
            </button>
          ))}
        </div>

        {/* Bookings List */}
        {loading ? (
          <div className="text-center text-muted-foreground py-20">Loading bookings...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center text-muted-foreground py-20">
            <Calendar size={48} className="mx-auto mb-4 opacity-40" />
            <p>No {filter === "all" ? "" : filter} bookings yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filtered.map((booking) => {
              const Icon = statusIcons[booking.status];
              return (
                <div key={booking.id} className="bg-background border border-border rounded-sm p-6 shadow-sm">
                  <div className="flex flex-col lg:flex-row lg:items-start gap-6">
                    {/* Booking Info */}
                    <div className="flex-1 space-y-3">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <h3 className="font-serif text-xl text-foreground">{booking.name}</h3>
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-full border ${statusColors[booking.status]}`}>
                          <Icon size={12} /> {booking.status}
                        </span>
                      </div>
                      <div className="grid sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2"><Mail size={14} /> {booking.email}</div>
                        <div className="flex items-center gap-2"><Phone size={14} /> {booking.phone}</div>
                        <div className="flex items-center gap-2"><Calendar size={14} /> {booking.check_in} → {booking.check_out}</div>
                        <div className="flex items-center gap-2"><Users size={14} /> {booking.guests} guest{booking.guests > 1 ? "s" : ""} · {booking.room_type}</div>
                      </div>
                      {booking.message && (
                        <div className="flex items-start gap-2 text-sm text-muted-foreground bg-muted/50 p-3 rounded-sm">
                          <MessageSquare size={14} className="mt-0.5 shrink-0" />
                          <p>{booking.message}</p>
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground">
                        Submitted {new Date(booking.created_at).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>

                    {/* Admin Actions */}
                    {booking.status === "pending" && (
                      <div className="lg:w-64 space-y-3 shrink-0">
                        <textarea
                          placeholder="Admin notes (optional)..."
                          value={adminNotes[booking.id] || ""}
                          onChange={(e) => setAdminNotes((prev) => ({ ...prev, [booking.id]: e.target.value }))}
                          className="w-full px-3 py-2 bg-secondary border border-border rounded-sm text-foreground text-sm resize-none h-20 focus:outline-none focus:ring-2 focus:ring-gold/50"
                        />
                        <div className="flex gap-2">
                          <button
                            onClick={() => updateStatus(booking.id, "accepted")}
                            className="flex-1 flex items-center justify-center gap-1.5 gold-gradient text-primary font-semibold py-2 rounded-sm text-xs uppercase tracking-wide hover:opacity-90 transition-opacity"
                          >
                            <CheckCircle size={14} /> Accept
                          </button>
                          <button
                            onClick={() => updateStatus(booking.id, "denied")}
                            className="flex-1 flex items-center justify-center gap-1.5 bg-destructive/10 text-destructive border border-destructive/30 font-semibold py-2 rounded-sm text-xs uppercase tracking-wide hover:bg-destructive/20 transition-colors"
                          >
                            <XCircle size={14} /> Deny
                          </button>
                        </div>
                      </div>
                    )}

                    {booking.status !== "pending" && booking.admin_notes && (
                      <div className="lg:w-64 shrink-0">
                        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Admin Notes</p>
                        <p className="text-sm text-foreground bg-muted/50 p-3 rounded-sm">{booking.admin_notes}</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
