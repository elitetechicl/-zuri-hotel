import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle, XCircle, Clock, Mail, Phone, Calendar, Users, MessageSquare, ArrowLeft } from "lucide-react";

type Booking = {
  id: string;
  name: string;
  email: string;
  phone: string;
  room_type: string;
  check_in: string;
  check_out: string;
  guests: number;
  message: string | null;
  status: "pending" | "accepted" | "denied";
  admin_notes: string | null;
  created_at: string;
};

const statusConfig = {
  pending: {
    icon: Clock,
    label: "Awaiting Confirmation",
    description: "Your booking has been received. Our team will confirm within 24 hours.",
    bg: "bg-yellow-50 dark:bg-yellow-900/20",
    border: "border-yellow-300",
    text: "text-yellow-800 dark:text-yellow-200",
  },
  accepted: {
    icon: CheckCircle,
    label: "Booking Confirmed",
    description: "Your reservation is confirmed. We look forward to welcoming you to Zuri Hotel.",
    bg: "bg-green-50 dark:bg-green-900/20",
    border: "border-green-300",
    text: "text-green-800 dark:text-green-200",
  },
  denied: {
    icon: XCircle,
    label: "Booking Unavailable",
    description: "Unfortunately, we're unable to accommodate this booking. Please see notes below or contact us.",
    bg: "bg-red-50 dark:bg-red-900/20",
    border: "border-red-300",
    text: "text-red-800 dark:text-red-200",
  },
};

const BookingStatus = () => {
  const { id } = useParams<{ id: string }>();
  const [booking, setBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;

    const fetchBooking = async () => {
      const { data } = await supabase.from("bookings").select("*").eq("id", id).maybeSingle();
      setBooking(data as Booking | null);
      setLoading(false);
    };

    fetchBooking();

    const channel = supabase
      .channel(`booking-${id}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "bookings", filter: `id=eq.${id}` }, (payload) => {
        setBooking(payload.new as Booking);
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [id]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-secondary text-muted-foreground">Loading your booking...</div>;
  }

  if (!booking) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-secondary px-6 text-center">
        <h1 className="font-serif text-3xl text-foreground mb-2">Booking Not Found</h1>
        <p className="text-muted-foreground mb-6">We couldn't find a booking with that reference.</p>
        <Link to="/" className="text-gold hover:underline text-sm uppercase tracking-wide">Return Home</Link>
      </div>
    );
  }

  const config = statusConfig[booking.status];
  const Icon = config.icon;

  return (
    <div className="min-h-screen bg-secondary">
      <header className="bg-primary text-primary-foreground py-4 px-6">
        <div className="container mx-auto flex items-center justify-between">
          <Link to="/" className="font-serif text-xl font-bold tracking-wide">
            ZURI <span className="text-gold">HOTEL</span>
          </Link>
          <Link to="/" className="text-primary-foreground/70 hover:text-gold text-sm flex items-center gap-1.5">
            <ArrowLeft size={14} /> Home
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-6 py-12 max-w-2xl">
        {/* Status Banner */}
        <div className={`rounded-sm border-2 ${config.border} ${config.bg} p-8 text-center mb-8`}>
          <Icon size={56} className={`mx-auto mb-4 ${config.text}`} />
          <h1 className={`font-serif text-3xl mb-2 ${config.text}`}>{config.label}</h1>
          <p className={`text-sm ${config.text} opacity-90`}>{config.description}</p>
        </div>

        {/* Booking Details */}
        <div className="bg-background border border-border rounded-sm p-6 shadow-sm">
          <div className="flex items-start justify-between mb-6 pb-4 border-b border-border">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Reservation</p>
              <h2 className="font-serif text-2xl text-foreground mt-1">{booking.name}</h2>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Reference</p>
              <p className="font-mono text-xs text-foreground mt-1">{booking.id.slice(0, 8).toUpperCase()}</p>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4 text-sm">
            <div className="flex items-start gap-3">
              <Mail size={16} className="text-gold mt-0.5 shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide">Email</p>
                <p className="text-foreground">{booking.email}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Phone size={16} className="text-gold mt-0.5 shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide">Phone</p>
                <p className="text-foreground">{booking.phone}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Calendar size={16} className="text-gold mt-0.5 shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide">Check-In</p>
                <p className="text-foreground">{new Date(booking.check_in).toLocaleDateString("en-US", { weekday: "short", month: "long", day: "numeric", year: "numeric" })}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Calendar size={16} className="text-gold mt-0.5 shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide">Check-Out</p>
                <p className="text-foreground">{new Date(booking.check_out).toLocaleDateString("en-US", { weekday: "short", month: "long", day: "numeric", year: "numeric" })}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Users size={16} className="text-gold mt-0.5 shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide">Guests</p>
                <p className="text-foreground">{booking.guests} · <span className="capitalize">{booking.room_type}</span> Room</p>
              </div>
            </div>
          </div>

          {booking.message && (
            <div className="mt-6 pt-4 border-t border-border">
              <div className="flex items-start gap-3 text-sm">
                <MessageSquare size={16} className="text-gold mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Your Request</p>
                  <p className="text-foreground">{booking.message}</p>
                </div>
              </div>
            </div>
          )}

          {booking.admin_notes && booking.status !== "pending" && (
            <div className="mt-6 pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">A Note from Zuri Hotel</p>
              <p className="text-sm text-foreground bg-muted/50 p-4 rounded-sm italic">{booking.admin_notes}</p>
            </div>
          )}
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6">
          Bookmark this page to check your booking status anytime.
        </p>
      </div>
    </div>
  );
};

export default BookingStatus;
