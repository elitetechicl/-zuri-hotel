import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const AdminSignup = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) {
      toast.error("Passwords do not match");
      return;
    }
    if (password.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("create-first-admin", {
        body: { email, password },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success("Admin account created! Signing you in...");
      const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
      if (signInError) throw signInError;
      navigate("/admin");
    } catch (err: any) {
      toast.error(err.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-primary flex items-center justify-center px-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <a href="/" className="font-serif text-2xl font-bold text-primary-foreground tracking-wide">
            ZURI <span className="text-gold">HOTEL</span>
          </a>
          <p className="text-primary-foreground/60 text-sm mt-2">Create First Admin Account</p>
        </div>
        <form onSubmit={handleSignup} className="bg-background p-8 rounded-sm shadow-2xl space-y-5">
          <div>
            <h2 className="font-serif text-2xl text-foreground mb-1">Sign Up</h2>
            <p className="text-muted-foreground text-xs">Only available if no admin exists yet.</p>
          </div>
          <div className="space-y-1">
            <label className="text-foreground text-sm font-medium">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              placeholder="admin@zurihotel.com"
            />
          </div>
          <div className="space-y-1">
            <label className="text-foreground text-sm font-medium">Password</label>
            <input
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              placeholder="At least 8 characters"
            />
          </div>
          <div className="space-y-1">
            <label className="text-foreground text-sm font-medium">Confirm Password</label>
            <input
              type="password"
              required
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className="w-full px-4 py-3 bg-secondary border border-border rounded-sm text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-gold/50"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full gold-gradient text-primary font-semibold py-3 rounded-sm tracking-wide uppercase text-sm hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {loading ? "Creating..." : "Create Admin Account"}
          </button>
          <p className="text-center text-muted-foreground text-xs">
            Already have an account?{" "}
            <a href="/admin/login" className="text-gold hover:underline">Sign in</a>
          </p>
        </form>
      </div>
    </div>
  );
};

export default AdminSignup;
